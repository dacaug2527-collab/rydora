import React from 'react'

const UserComp = () => {
  return (
    <div>UserComp</div>
  )
}

export default UserComp